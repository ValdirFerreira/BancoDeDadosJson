﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebProjetoBanco.Models.Entidades
{
    public class Usuarios
    {
        public string Id { get; set; }

        public string NomeUsuario { get; set; }
    }
}
