﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebProjetoBanco.Models.Negocio
{
    public interface IDominioJson<T> where T : class
    {

        bool ValidaArquivo(string nome, string webRoot);

        bool Salvar(T Objeto, string nome, string webRoot);

        List<T> Listar(string nome, string webRoot);

        void Edicao(List<T> Listar, string nome, string webRoot);
    }
}
