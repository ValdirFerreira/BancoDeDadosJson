﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebProjetoBanco.Models.Entidades;

namespace WebProjetoBanco.Models.Negocio
{
    public interface IDominioUsuario : IDominioJson<Usuarios>
    {
    }
}
