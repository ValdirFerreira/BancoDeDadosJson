﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebProjetoBanco.Models.Negocio
{
    public interface IDominioProduto : IDominioJson<Produto>
    {
    }
}
