﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WebProjetoBanco.Models.Negocio;

namespace WebProjetoBanco.Models.Repositorio
{
    public class RepositorioJson<T> : IDominioJson<T>, IDisposable where T : class
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Listar"></param>
        /// <param name="nome"></param>
        /// <param name="webRoot"></param>
        public void Edicao(List<T> Listar, string nome, string webRoot)
        {
            var arquivo = string.Concat(webRoot, "/BancoJson/" + nome, ".json");

            var JsonSalvar = JsonConvert.SerializeObject(Listar);

            using (StreamWriter write = new StreamWriter(arquivo))
            {
                write.Write(JsonSalvar);
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="nome"></param>
        /// <param name="webRoot"></param>
        /// <returns></returns>
        public List<T> Listar(string nome, string webRoot)
        {
            var retorno = new List<T>();

            var arquivo = string.Concat(webRoot, "/BancoJson/" + nome, ".json");

            using (StreamReader read = new StreamReader(arquivo))
            {
                string json = read.ReadToEnd();

                retorno = JsonConvert.DeserializeObject<List<T>>(json);
            }

            return retorno;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Objeto"></param>
        /// <param name="nome"></param>
        /// <param name="webRoot"></param>
        /// <returns></returns>
        public bool Salvar(T Objeto, string nome, string webRoot)
        {
            var retorno = new List<T>();

            try
            {
                var arquivo = string.Concat(webRoot, "/BancoJson/" + nome, ".json");

                using (StreamReader read = new StreamReader(arquivo))
                {
                    string json = read.ReadToEnd();

                    retorno = JsonConvert.DeserializeObject<List<T>>(json);
                }


                if (retorno == null)
                {
                    retorno = new List<T>();
                }

                retorno.Add(Objeto);

                var JsonSalvar = JsonConvert.SerializeObject(retorno);

                using (StreamWriter Write = new StreamWriter(arquivo))
                {
                    Write.Write(JsonSalvar);
                }


            }
            catch (Exception ex)
            {

                return false;
            }


            return true;

        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="nome"></param>
        /// <param name="webRoot"></param>
        /// <returns></returns>
        public bool ValidaArquivo(string nome, string webRoot)
        {
            var arquivo = string.Concat(webRoot, "/BancoJson/" + nome, ".json");

            if (!File.Exists(arquivo))
            {
                try
                {

                    using (FileStream fs = File.Create(arquivo))
                    {

                    }

                }
                catch (Exception ex)
                {

                    return false;
                }

            }

            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }



    }
}
