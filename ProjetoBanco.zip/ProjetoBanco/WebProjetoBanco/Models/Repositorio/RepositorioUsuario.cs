﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebProjetoBanco.Models.Entidades;
using WebProjetoBanco.Models.Negocio;

namespace WebProjetoBanco.Models.Repositorio
{
    public class RepositorioUsuario : RepositorioJson<Usuarios>, IDominioUsuario
    {
    }
}
