﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebProjetoBanco.Models.Negocio;

namespace WebProjetoBanco.Models.Repositorio
{
    public class RepositorioProduto : RepositorioJson<Produto>, IDominioProduto
    {
    }
}
